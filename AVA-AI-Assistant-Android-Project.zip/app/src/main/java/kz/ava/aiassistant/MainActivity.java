package kz.ava.aiassistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 101;
    private static final int MEDIA_REQUEST = 102;
    private LinearLayout messages;
    private EditText input;
    private ScrollView scroll;
    private TextToSpeech tts;
    private String mode = "Чат";
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12, 16, 31));
        getWindow().setNavigationBarColor(Color.rgb(12, 16, 31));
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("ru", "RU"));
        });
        buildUi();
        addMessage("AVA", "Сәлем! Мен AVA AI Assistant көмекшісімін. Сұрағыңды жаз немесе дауыспен айт.\n\nЕскерту: бұл бастапқы нұсқа. Нақты AI жауаптары үшін API серверін қосу керек.");
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));
        root.setBackgroundColor(Color.rgb(12,16,31));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("AVA AI Assistant", 25, Color.WHITE);
        title.setTypeface(null, 1);
        TextView sub = text("Чат • Дауыс • Сурет • Видео", 13, Color.rgb(169,180,207));
        header.addView(title); header.addView(sub);
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(62)));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Чат", "Дауыс", "Сурет", "Видео"};
        for (String name : names) {
            Button b = button(name);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1);
            p.setMargins(dp(2), dp(8), dp(2), dp(8));
            tabs.addView(b, p);
            b.setOnClickListener(v -> {
                mode = name;
                if (name.equals("Дауыс")) startVoice();
                else if (name.equals("Сурет")) chooseMedia("image/*");
                else if (name.equals("Видео")) chooseMedia("video/*");
                else addMessage("AVA", "Чат режимі қосылды. Сұрағыңды төменге жаз.");
            });
        }
        root.addView(tabs);

        status = text("Дайын • Интернет қажет емес (демо режим)", 12, Color.rgb(169,180,207));
        status.setPadding(0, dp(4), 0, dp(6));
        root.addView(status);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, dp(4), 0, dp(8));
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setSingleLine(false);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.rgb(150,160,185));
        input.setHint("AVA-ға хабарлама...");
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        input.setBackgroundColor(Color.rgb(30,37,60));
        composer.addView(input, new LinearLayout.LayoutParams(0, dp(52), 1));
        Button send = button("Жіберу");
        LinearLayout.LayoutParams sendp = new LinearLayout.LayoutParams(dp(90), dp(52));
        sendp.setMargins(dp(8), 0, 0, 0);
        composer.addView(send, sendp);
        send.setOnClickListener(v -> sendMessage());
        root.addView(composer);
        setContentView(root);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(12); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(83,91,220)));
        return b;
    }

    private void addMessage(String who, String body) {
        TextView bubble = text(who + "\n" + body, 15, Color.WHITE);
        bubble.setPadding(dp(14), dp(10), dp(14), dp(10));
        bubble.setBackgroundColor(who.equals("AVA") ? Color.rgb(30,37,60) : Color.rgb(50,61,115));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5));
        messages.addView(bubble, p);
        if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void sendMessage() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) return;
        addMessage("Сен", q);
        input.setText("");
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
        String answer;
        String lower = q.toLowerCase(Locale.ROOT);
        if (lower.contains("сәлем") || lower.contains("салем") || lower.contains("привет")) {
            answer = "Сәлем! Қалай көмектесе аламын?";
        } else if (lower.contains("код") || lower.contains("программ")) {
            answer = "Бағдарлама бойынша көмектесемін. Нақты AI жауаптары үшін серверге AI API қосу қажет.";
        } else if (lower.contains("сурет")) {
            answer = "Сурет бөліміне өтіп, телефоныңнан сурет таңдай аласың. Жаңа сурет генерациясы әзірге қосылмаған.";
        } else if (lower.contains("видео") || lower.contains("виде")) {
            answer = "Видео бөлімінде телефоннан видео таңдауға болады. Толық монтаж және экспорт келесі нұсқада қосылады.";
        } else {
            answer = "Сұрағың қабылданды. Бұл демо-нұсқада жауаптар үлгі бойынша беріледі. Нақты AI үшін API серверін қосу керек.";
        }
        addMessage("AVA", answer);
    }

    private void startVoice() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "kk-KZ");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Сөйлеңіз...");
        try { startActivityForResult(intent, VOICE_REQUEST); }
        catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Бұл құрылғыда дауыс тану қызметі жоқ.", Toast.LENGTH_LONG).show();
        }
    }

    private void chooseMedia(String type) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType(type);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(Intent.createChooser(intent, "Файл таңдаңыз"), MEDIA_REQUEST); }
        catch (Exception e) { Toast.makeText(this, "Файл таңдау ашылмады.", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == VOICE_REQUEST) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                input.setText(results.get(0));
                mode = "Чат";
                sendMessage();
            }
        } else if (requestCode == MEDIA_REQUEST) {
            Uri uri = data.getData();
            if (uri != null) {
                String label = mode.equals("Сурет") ? "Сурет таңдалды" : "Видео таңдалды";
                addMessage("AVA", label + ":\n" + uri.getLastPathSegment() + "\nФайлды таңдадың. Толық өңдеу функциясы бұл бастапқы нұсқада жоқ.");
                status.setText(label + " • " + uri.getLastPathSegment());
                if (mode.equals("Видео")) {
                    Intent view = new Intent(Intent.ACTION_VIEW);
                    view.setDataAndType(uri, "video/*");
                    view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(view); } catch (Exception ignored) {}
                } else {
                    Intent view = new Intent(Intent.ACTION_VIEW);
                    view.setDataAndType(uri, "image/*");
                    view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(view); } catch (Exception ignored) {}
                }
            }
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
