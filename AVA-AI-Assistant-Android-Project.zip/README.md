# AVA AI Assistant — Android

Android бастапқы жобасы: қазақша интерфейс, демо-чат, Android жүйесі арқылы дауыс тану, мәтінді дауыстап оқу үшін TTS инициализациясы, телефоннан сурет/видео таңдау.

## Маңызды
Бұл — бастапқы MVP/демо. Чат жауаптары әзірге үлгі жауаптар; нақты генеративті AI, жаңа сурет генерациясы, бейне монтаж/экспорт және бұлттық синхрондау қосылмаған. Оларды қосу үшін қауіпсіз backend және API кілті қажет. API кілтін Android кодының ішіне жазбаңыз.

## GitHub арқылы APK жинау
1. GitHub-та `AVA-AI-Assistant` атты **Public немесе Private** репозиторий жасаңыз.
2. Осы ZIP архивін ашып, ішіндегі файлдар мен `.github` папкасын репозиторийдің түбіріне жүктеңіз.
3. Өзгерістерді `main` тармағына commit етіңіз.
4. Репозиторийдегі **Actions** бөліміне өтіңіз. `Build AVA AI Assistant APK` workflow іске қосылады.
5. Жасыл белгі шыққан соң workflow run-ды ашып, төмендегі **Artifacts** бөлімінен `AVA-AI-Assistant-debug-APK` файлын жүктеңіз.
6. ZIP артефактын ашыңыз — ішінде `app-debug.apk` болады. Бұл тестілеуге арналған debug APK, Play Store-ға арналған қолтаңбаланған релиз емес.

## Құрылғыға орнату
APK-ны Android телефонына көшіріп, ашыңыз. Телефон белгісіз көзден орнатуға рұқсат сұраса, тек өзіңіз жасаған файлға рұқсат беріңіз.

## Жобаны жергілікті жинау
- JDK 17
- Gradle 8.7
- Android SDK Platform 35
- Команда: `gradle assembleDebug`

## Негізгі файлдар
- `app/src/main/java/kz/ava/aiassistant/MainActivity.java` — қосымшаның коды
- `app/src/main/AndroidManifest.xml` — Android рұқсаттары мен activity
- `.github/workflows/build-apk.yml` — GitHub Actions арқылы APK жинау
